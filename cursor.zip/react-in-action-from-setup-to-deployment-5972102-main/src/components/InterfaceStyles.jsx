export const buttonStyle = {
  backgroundColor: 'yellow',
  color: 'red',
  border: 'none'
}